# Vật lý 1 – PWA

## Nội dung
- `index.html`: nội dung học liệu gốc, giữ nguyên phần bài học và các mô phỏng/bài tập; bổ sung tối ưu điện thoại.
- `manifest.webmanifest`: cấu hình cài đặt PWA.
- `sw.js`: lưu bộ khung ứng dụng để mở lại khi ngoại tuyến.
- `icons/`: biểu tượng ứng dụng.

## Chạy thử
PWA cần được mở qua HTTPS hoặc `localhost`, không mở trực tiếp bằng `file://`.

Cách thử trên máy tính:
1. Giải nén thư mục.
2. Mở terminal tại thư mục này.
3. Chạy `python -m http.server 8000`.
4. Mở `http://localhost:8000`.

## Đưa lên mạng để cài trên điện thoại
Đăng tải toàn bộ nội dung thư mục này lên dịch vụ hosting tĩnh có HTTPS (ví dụ GitHub Pages, Netlify hoặc Cloudflare Pages), sau đó mở URL trên điện thoại:
- Android/Chrome: chọn “Cài đặt ứng dụng” hoặc “Thêm vào màn hình chính”.
- iPhone/Safari: Chia sẻ → “Thêm vào MH chính”.

## Ngoại tuyến
Sau khi mở ứng dụng online ít nhất một lần để service worker cài cache, trang chính và tài nguyên cùng miền có thể mở lại khi mất mạng. MathJax và phông chữ tải từ CDN bên ngoài có thể cần mạng nếu chưa được trình duyệt lưu cache.
